SMTP NOTIFICATIONS
==================

This component will override default emails notificatios and allows ossn system to send notification emails using your smtp server.
Few hosting providers didn't have php mail() enabled, Users belong to this category can try this component.

Installation
============

Install it using component installer and after installation go to components and enable it. Configure component settings.

Requires OSSN V4.2 or >
