.ossn-form textarea#post-edit {
    height: 125px;
}
.ossn-wall-post-delete {
    color: #EC2020 !important;
}