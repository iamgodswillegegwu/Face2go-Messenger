<?php
	OssnUser::Logout();
 	redirect('administrator?logout=true');